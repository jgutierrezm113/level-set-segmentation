

extern int width;
extern int height;
